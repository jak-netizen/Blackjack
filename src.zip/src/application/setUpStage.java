package application;




import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class setUpStage extends Stage {
	static String name;
	
	Label nameInLabel = new Label("You got a name?");
	TextField nameInput = new TextField();
	Button submitName = new Button("Play BlackJack");
	VBox introScreen = new VBox();
	
	
	setUpStage(){
		introScreen.getChildren().addAll(nameInLabel,nameInput,submitName);
		this.setScene(new Scene(introScreen,350,300));
		this.show();
		
		submitName.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent t) {
				BlackJackVisual.name = nameInput.getText(); 
				new BlackJackVisual();
				close();
			}
		});
	}	
}
