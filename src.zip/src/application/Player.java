package application;



//relatively self explanatory, probably done poorly

//not gonna comment through :)

public class Player{
	
	private String name;
	
	private double balance = 250000; 
	
	private double bet;
	
	private Hand playerHand;
	
	private boolean hitChoice;
	
	
	
	public Player() {
		this(new Hand(),"Joe", 250000, 0);
		
	}
	
	public Player(Hand hand, String name, double balance, double bet) {
		this.playerHand = hand;
		this.name = name;
		this.balance = balance;
		this.bet = bet;
	}
	
	public double getBet() {
		return bet;
	}
	public void setBet(double bet) {
		this.bet = bet;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	
	public boolean getHitChoice() {
		return hitChoice;
	}

	public void setHitChoice(boolean hitChoice) {
		this.hitChoice = hitChoice;
	}

	
	
	public Hand getPlayerHand() {
		return playerHand;
	}

	public void setPlayerHand(Hand playerHand) {
		this.playerHand = playerHand;
	}
		
}