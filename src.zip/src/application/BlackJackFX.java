package application;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.paint.*;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;


public class BlackJackFX extends Application{
	
	private boolean stood;
	
	private boolean dealt;
	
	private static Deck deck = new Deck();
	
	private static Player player = new Player();
	
	private static Dealer dealer = new Dealer();
	
	private Hand playerHand = new Hand();
	
	private Hand dealerHand = new Hand();

	public  boolean dealerWin = false;
	
	public  boolean playerWin = false;
	
	public  boolean push = false;
	
	public  boolean gameWon = false;
	
	public String gameText = "";
	

	//ready deck acts on deck object to populate deck and perform initial shuffle
	
	public void readyDeck(Deck deck)  {		
		deck.generateDeck();
		deck.shuffleDeck();
	}


	/*
	 * 
	 *shuffle shuffles deck, placed throughout the program
	 *only takes actions if 52 cards have been dealt
	 *
	 */

	public void shuffle(Deck deck) {
			deck.shuffleDeck();
	}

	 

	/*
	 * deal handles the dealing of the first 4 cards
	 * 1 to player, 1 to dealer, 1 to player, 1 to dealer
	 * also gets value of each hand for later use
	 * 
	 */


	public void deal() {
		player.setBalance(player.getBalance() - player.getBet());
		
		playerHand.handCards[0] = Deck.dealCard();
		
		dealerHand.handCards[0] = Deck.dealCard();
		
		playerHand.handCards[1] = Deck.dealCard();
		
		dealerHand.handCards[1] = Deck.dealCard();
		
		player.setPlayerHand(playerHand);
		dealer.setDealerHand(dealerHand, true);
		
		player.getPlayerHand().getHandValue();
		dealer.getDealerHand().getHandValue();
		dealt = true;
	}


	//clearHands calls clearHand from Hand, sets all cards to null
	//used at end of round to reset for next

	public void clearHands(int size, int size2, ImageView card, FlowPane heldCards, ImageView dealerCard, FlowPane dealerCards) {
		
		
		dealt = false;
		playerWin = false;
		dealerWin = false;
		push = false;
		gameWon = false;
	 
		dealerCard = new ImageView();
		for (int i = 0; i < size2; i++) {
			dealerCard.setImage(null);
			dealerCard.setFitHeight(100);
			dealerCard.setFitWidth(100);
			dealerCard.setPreserveRatio(true);
			dealerCards.getChildren().clear();;
		}
		card = new ImageView();
		for (int i = 0; i < size; i++) {
			card.setImage(null);
			card.setFitHeight(100);
			card.setFitWidth(100);
			card.setPreserveRatio(true);
			heldCards.getChildren().clear();;
		}
		
		Hand hand1 = new Hand();
		hand1 = player.getPlayerHand();
		
		Hand hand2 = new Hand();
		hand2 = dealer.getDealerHand();
		
		hand1.clearHand();
		player.setPlayerHand(hand1);
		
		hand2.clearHand();
		dealer.setDealerHand(hand2, true);
	}
	

	/*
	 * 
	 * moveMoney handles the exchange of money placed on bets 
	 * in event of player winning, they receive twice their bet back
	 * in event of a push they receive their initial bet back
	 * in event of a loss nothing occurs because their bet is already on the table
	 * 	therefore no change to balance needed
	 * post adjustment balance is displayed at the end
	 *  
	 */


	public void moveMoney() {
		if (playerWin) {
			player.setBalance(player.getBalance() + (player.getBet() * 2));
		} else if (push) {
			player.setBalance(player.getBalance() + player.getBet());
		} 
		
	}

	/*
	 * hit handles hit behavior
	 * a player may hit if:
	 *   -they have not already won
	 *   -the dealer has not already won
	 *   -they have not busted
	 * they may continue hitting until one of the above conditions is met
	 * after each hit the whoWins method is called to check for a winner
	 * 
	 */


	public void hit() {
				
			playerHand.addHitCard();
			player.setPlayerHand(playerHand);
			
			player.getPlayerHand().handChecks();
			player.getPlayerHand().getHandValue();
			if (player.getPlayerHand().isBust || player.getPlayerHand().isBlackJack) {
				whoWins();
			}
	}
	

	/*
	 *  whoWins checks both hands for all possible end game conditions
	 *  finds blackJacks, busts, and value based wins/losses
	 *  flags a winner if found, push is hands equal
	 *  flags an game over boolean when a winner is found
	 *  boolean for the dealer's hidden card is used to prevent 
	 *   certain checks from being activated early
	 *  
	 */


	public void whoWins() {
		
		
	  Hand hand1 = player.getPlayerHand();
	  Hand hand2 = dealer.getDealerHand();
		
	  hand1.handChecks();
	  hand2.handChecks();
	  if (!gameWon) {
		
	    if (hand2.isBlackJack && hand1.isBlackJack) {
			dealer.setDealerHide(false);
			push = true;
			gameWon = true;
			
			gameText = "Two BlackJacks! Push.";
		}
		
		else if (hand2.isBlackJack) {
			dealer.setDealerHide(false);
			dealerWin = true;
			gameWon = true;
			
			gameText = "Dealer has BlackJack! Dealer wins.";
			
		}
		
		else if (hand1.isBlackJack) {
			playerWin = true;
			gameWon = true;
			
			gameText = "BlackJack! " + player.getName().toString() + " wins." ;
		} 
		
		else if (hand1.isBust) {
			dealerWin = true;
			gameWon = true;
			
			gameText = player.getName().toString() + " busts. Dealer wins!";
		} 
		
		else if (hand2.isBust) {	
			playerWin = true;
			gameWon = true;
			
			gameText = "Dealer busts. " + player.getName().toString() + " wins!";
		}

		else if (!dealer.getDealerHide()){

		
			if (hand1.getHandValue() > hand2.getHandValue()) {
				playerWin = true;
				gameWon = true;
				
				gameText = Integer.toString(player.getPlayerHand().getHandValue()) + 
					 	" beats " + 
					 	Integer.toString(dealer.getDealerHand().getHandValue()) + ". " + 
					 	player.getName().toString() + " wins!";
			}
			
			 else if (hand1.getHandValue() < hand2.getHandValue()) {
				 gameText = Integer.toString(dealer.getDealerHand().getHandValue()) + 
						 	" beats " + 
						 	Integer.toString(player.getPlayerHand().getHandValue()) + 
						 	". Dealer wins!";
				 
				 dealerWin = true;
				 gameWon = true;
			}
			
			 else if(hand1.getHandValue() == hand2.getHandValue()) {
				 gameText = "Push! Money back";
				 
				 gameWon = true;
				 push = true;
			}
		}
	  }
	} 
	
	
	//sets the dealer's hit choice
	//also returns a bool to do exactly that 
	//not sure if game will explode if i try to change it
	
	public boolean dealerChoice() {
		if (dealer.getDealerHand().getHandValue() > 16 || 
				dealer.getDealerHand().getHandValue() > player.getPlayerHand().getHandValue()) {
		  			
					dealer.setHitChoice(false);
					return false;
				} else {
					dealer.setHitChoice(true);
					return true;
				} 
	}

	/*
	*  method that handles dealer behavior
	*  dealer hits until >16 or >player's hand, whatever comes first	
	*  reveals dealers flip card, prints hand each time card is dealt
	*  while loop will not start if a game ending condition has already been met
	*/
	
	
	public void dealer() {
		
		Hand tempDealerHand = new Hand();
		tempDealerHand = dealer.getDealerHand();
		
		
		while (dealer.getHitChoice() && !gameWon) {
			
			tempDealerHand.addHitCard();
			
			dealer.setDealerHand(tempDealerHand, dealer.getHitChoice());
			
			dealerChoice();
			whoWins();
		}
	}


	@Override
	public void start(Stage primaryStage){
		
		//lotta labels thrown around below here
		//not sure if they're all even in the scene
		Font font1 = new Font(java.awt.Font.SERIF, 15);
		Font font2 = new Font(java.awt.Font.SERIF, 12);
		Label dealerLb = new Label("Dealer");
		dealerLb.setTextFill(Color.BLACK);
		
		
		Label chipsLabel = new Label("Chips:");
		Label nameLabel = new Label(player.getName());
		Label balanceLabel = new Label("Cash: " + Double.toString(player.getBalance()));
		
	
		//buttons to place bets with
		final Button chip1 = new Button("100");
		final Button chip2 = new Button("250");
		final Button chip3 = new Button("500");
		final Button chip4 = new Button("1K");
		final Button chip5 = new Button("2K");
		final Button chip6 = new Button("5K");
		final Button chip7 = new Button("10K");
		
		final Button submitBetBt = new Button(" DEAL ");
		final Button hitBt = new Button("   HIT   ");
		final Button standBt = new Button("STAND");
		
		chip1.setFont(font2);
		chip2.setFont(font2);
		chip3.setFont(font2);
		chip4.setFont(font2);
		chip5.setFont(font2);
		chip6.setFont(font2);
		chip7.setFont(font2);
		
		nameLabel.setFont(font1);
		balanceLabel.setFont(font1);
		chipsLabel.setFont(font1);
		hitBt.setFont(font1);
		standBt.setFont(font1);
		submitBetBt.setFont(font1);
		
		
		Chips chips = new Chips(chip1, chip2,chip3,chip4,chip5,chip6,chip7);
		
		NameBalance nameBalance = new NameBalance(nameLabel, balanceLabel);
		
		PlayerButtons playerButtons = new PlayerButtons(chipsLabel, hitBt, standBt, submitBetBt, chips);
		
		Label playerCards = new Label(player.getPlayerHand().toString());
		playerCards.setTextFill(Color.BLACK);
		
		FlowPane heldCards = new FlowPane();
		
		PlayerPane playerPane = new PlayerPane(playerCards, nameBalance, playerButtons, heldCards);
		
		
		FlowPane dealerCards = new FlowPane();
		
		
		GridPane dealerPane = new GridPane();
		dealerPane.add(dealerLb, 0, 0);
		dealerPane.add(dealerCards, 0, 1);
		GridPane.setMargin(dealerLb,new Insets( 20,20,20,20));
		
		BorderPane gameTable = new BorderPane();
		
	
		VBox messageBox = new VBox();
		Label winMessage = new Label("");
		Label betLabel = new Label("Bet:" + Double.toString(player.getBet()));
		Font font = new Font(java.awt.Font.SANS_SERIF, 21);
		
		betLabel.setFont(font);
		winMessage.setTextFill(Color.BLACK);
		winMessage.setMinSize(20,20);
		messageBox.getChildren().add(0, winMessage);
		messageBox.getChildren().add(1, betLabel);
		
		
		gameTable.setTop(dealerPane);
		dealerPane.setAlignment(Pos.CENTER);
		gameTable.setBottom(playerPane);
		
		
			
		gameTable.setCenter(heldCards);
		heldCards.setAlignment(Pos.BOTTOM_CENTER);
		Label dealerStr = new Label(dealer.getDealerHand().toString());
		gameTable.setRight(messageBox);
		messageBox.setAlignment(Pos.CENTER);
		gameTable.setLeft(dealerStr);
		dealerStr.setAlignment(Pos.TOP_CENTER);
		
		
		
		ResizeCanvas primary = new ResizeCanvas();
		
		
		Image tableTop = new Image("/image/TableNew.jpg");
		ImagePattern top = new ImagePattern(tableTop);
		
		Rectangle backGround = new Rectangle(800,400);
		backGround.setFill(top);
		StackPane gameGroup = new StackPane(gameTable, backGround,primary);
		
		backGround.widthProperty().bind(gameGroup.widthProperty());
		backGround.heightProperty().bind(gameGroup.heightProperty());
		
		
		
		primary.widthProperty().bind(gameGroup.widthProperty());
		primary.heightProperty().bind(gameGroup.widthProperty());
		
		gameTable.toFront(); 
		gameTable.setMinWidth(800);
		gameTable.setMinHeight(400);
		backGround.setOpacity(.9);
		
		readyDeck(deck);
		
		shuffle(deck);
			
		
		//chips set the player bet, is deducted from balance when deal is pressed
		chip1.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent t) {
				player.setBet(100);
				betLabel.setText("Bet: " + Double.toString(100));
			}
			
		});
		chip2.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent t) {
				player.setBet(250);
				betLabel.setText("Bet: " + Double.toString(250));
			}
			
		});
		chip3.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent t) {
				player.setBet(500);
				betLabel.setText("Bet: " + Double.toString(500));
			}
			
		});
		chip4.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent t) {
				player.setBet(1000);
				betLabel.setText("Bet:" + Double.toString(1000));
			}
			
		});
		chip5.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent t) {
				player.setBet(2500);
				betLabel.setText("Bet: " + Double.toString(2500));
			}
			
		});
		chip6.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent t) {
				player.setBet(5000);
				betLabel.setText("Bet: " + Double.toString(5000));
			}
			
		});
		chip7.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent t) {
				player.setBet(10000);
				betLabel.setText("Bet: " + Double.toString(10000));
			}
			
		});;
		
		
		
		//starts the game, 2 cards dealt to player 2 to dealer
		//displays the cards when it wants to 
		submitBetBt.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent t) {
			 if (!dealt && player.getBet() > 0) {	
				winMessage.setText("");
				stood = false;
				ImageView card = new ImageView();
				ImageView dealerCard = new ImageView();

				clearHands(player.getPlayerHand().getHandSize(),dealer.getDealerHand().getHandSize(),card, heldCards, dealerCard, dealerCards);
				deal(); 
				dealerCard.setImage(new Image(dealer.getDealerHand().getHandCards(0).getImg()));
				dealerCard.setFitHeight(100);
				dealerCard.setFitWidth(100);
				dealerCard.setPreserveRatio(true);
				dealerCards.getChildren().add(dealerCard);
				
				if (dealer.getDealerHand().getHandValue() == 21) {
					dealerStr.setText(dealer.getDealerHand().toString());
				}else {
					dealerStr.setText(dealer.getDealerHand().getHandCards(0).toString());
				}
				for (int i = 0; i < 2; i++) {
					card = new ImageView();
					card.setImage(new Image(player.getPlayerHand().getHandCards(i).getImg()));
					card.setFitHeight(100);
					card.setFitWidth(100);
					card.setPreserveRatio(true);
					
					heldCards.getChildren().add(card);
				}
				
				dealt = true;
				playerCards.setText(player.getPlayerHand().toString());
				
				balanceLabel.setText(Double.toString(player.getBalance()));
				
				whoWins();
				
				if (gameWon) {
					
					winMessage.setText(gameText);
					
					moveMoney();
					
					balanceLabel.setText(Double.toString(player.getBalance()));
					dealt = false;
					gameWon = false;
				}
			}
		}
		});
		
		
		//hit fires an event that adds a card to player hand
		//runs usual checks to see if game ending condition is met
		//displays the new cards if it's in a good mood
		hitBt.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent t) {
				ImageView dealerCard = new ImageView();
				ImageView card = new ImageView();
				if (dealt && !gameWon && !stood) {
					hit();
					int hits = player.getPlayerHand().getHandSize();
					
						card = new ImageView();
						card.setImage(new Image(player.getPlayerHand().getHandCards(hits-1).getImg()));
						card.setFitHeight(100);
						card.setFitWidth(100);
						card.setPreserveRatio(true);
						heldCards.getChildren().add(hits-1,card);
						
						playerCards.setText(player.getPlayerHand().toString());
					
					
					whoWins();
					if (gameWon) {
						winMessage.setText(gameText);
						whoWins();
						moveMoney();
						balanceLabel.setText(Double.toString(player.getBalance()));
						dealerCard = new ImageView();
						card = new ImageView();
						dealt = false;
						gameWon = false;
						stood = false;
					}
					
				}
				
			}
		});
		
		
		//ends the players turn and lets dealer run its moves
		//dealer will hit until beating player or busting
		//works once a month
		standBt.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent t) {
			 if(dealt && !gameWon && !stood) {
				stood = true;
				ImageView dealerCard = new ImageView();
				ImageView card = new ImageView();
				whoWins();
				for (int i = 1; i < dealer.getDealerHand().getHandSize(); i++) {
					dealerCard = new ImageView();
					dealerCard.setImage(new Image(dealer.getDealerHand().getHandCards(i).getImg()));
					dealerCard.setFitHeight(100);
					dealerCard.setFitWidth(100);
					dealerCard.setPreserveRatio(true);
					dealerCards.getChildren().add(dealerCard);
					dealerStr.setText(dealer.getDealerHand().toString());
				}
				
					
				dealer.setHitChoice(dealerChoice());
					
					
				int lastSize = dealer.getDealerHand().getHandSize();
					
				if (dealer.getHitChoice()) {
					dealer();
				}
				int newSize = dealer.getDealerHand().getHandSize();
				for (int i = lastSize; i < newSize; i++) {		
					dealerCard = new ImageView();
					dealerCard.setImage(new Image(dealer.getDealerHand().getHandCards(i).getImg()));
					dealerCard.setFitHeight(100);
					dealerCard.setFitWidth(100);
					dealerCard.setPreserveRatio(true);
					dealerCards.getChildren().add(dealerCard);
					dealerStr.setText(dealer.getDealerHand().toString());							
											
					dealer.setHitChoice(dealerChoice());
				}
				whoWins();
				winMessage.setText(gameText);
				moveMoney();
				balanceLabel.setText(Double.toString(player.getBalance()));
				dealt = false;	
				gameWon = false;
				dealerWin = false;
				playerWin = false;
				
			 	}
			}
		});
	
		Scene scene = new Scene(gameGroup, 1200, 700);
		
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
		
		
		}

//below here are a bunch of panes and such 
//probably did not need to do any of this
//the resize canvas is nice though, tracks window size and adjusts elements accordingly
	class GameTable extends BorderPane{
		public GameTable(PlayerPane playerPane, DealerPane dealerPane) {
			getChildren().addAll(playerPane, dealerPane);
			setTop(dealerPane);
		}
	}
	
	class DealerPane extends GridPane{
		
	}
	
	class NameBalance extends VBox{
		
		public NameBalance(Label nameLabel, Label balanceLabel) {
			getChildren().addAll(nameLabel, balanceLabel);
			nameLabel.setTextFill(Color.BLACK);
			balanceLabel.setTextFill(Color.BLACK);
		}
	}
	
	class Chips extends HBox{
		
		public Chips(Button chip1,Button chip2,Button chip3,Button chip4,
				     Button chip5, Button chip6, Button chip7) {
			getChildren().addAll(chip1,chip2,chip3,chip4,chip5,chip6,chip7);
		}
	}
	
	class PlayerButtons extends GridPane{
		
		public PlayerButtons(Label chipsLabel,Button hitBt, Button standBt, Button submitBetBt, Chips chips) {
			getChildren().addAll(chipsLabel, hitBt, standBt, submitBetBt, chips);
			
			setColumnIndex(hitBt, 1);
			setRowIndex(hitBt, 0);
			
			setColumnIndex(standBt, 1);
			setRowIndex(standBt, 1);
			
			setColumnIndex(submitBetBt, 1);
			setRowIndex(submitBetBt, 2);
			
			setColumnIndex(chipsLabel, 0);
			setRowIndex(chipsLabel, 0);
			
			setColumnIndex(chips, 0);
			setRowIndex(chips, 1);
			
			setMargin(chips, new Insets(0,40,0,20));
			
		}
	}
	
	class PlayerPane extends GridPane {	
		public PlayerPane(Label playerCards, NameBalance nameBalance, PlayerButtons playerButtons, FlowPane heldCards) {
			getChildren().addAll(playerCards, nameBalance, playerButtons, heldCards);
			setMargin(nameBalance, new Insets(20,20,20,40));
			setValignment(nameBalance, VPos.CENTER);
			setHalignment(nameBalance, HPos.LEFT);
			setColumnIndex(nameBalance, 0);
			setRowIndex(nameBalance, 1);
			
			setMargin(playerCards, new Insets(20,20,20,40));
			setValignment(playerCards, VPos.CENTER);
			setHalignment(playerCards, HPos.CENTER);
			setColumnIndex(playerCards, 0);
			setRowIndex(playerCards, 2);
			
			
			setMargin(heldCards, new Insets(15,15,15,30));
			setValignment(heldCards, VPos.CENTER);
			setHalignment(heldCards, HPos.CENTER);
			setColumnIndex(heldCards, 0);
			setRowIndex(heldCards, 3);
			
			
			setMargin(playerButtons, new Insets(20,20,20,40));
			setValignment(playerButtons, VPos.CENTER);
			setHalignment(playerButtons, HPos.RIGHT);
			setColumnIndex(playerButtons, 10);
			setRowIndex(playerButtons, 2);
			setHgap(20);
			
		}
	}
	public class ResizeCanvas extends Canvas{
		public ResizeCanvas() {
			widthProperty().addListener(evt -> draw());
			heightProperty().addListener(evt -> draw());
		}
		public void draw() {


		}
		@Override 
		public boolean isResizable() {
			return true;
		}
		@Override
		public double prefWidth(double height) {
			return getWidth();
		}
		@Override
		public double prefHeight(double width) {
			return getHeight();
		}
	}
	

}











