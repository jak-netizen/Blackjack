package application;










public class Card {
	
	//create enum of rank/suit values
	//13 ranks, 4 suits, assigned randomly per card in deck class
	public enum ranks {
		Ace, Two, Three, Four, Five, Six, Seven,
		Eight, Nine, Ten, Jack, Queen, King;
		}
	public enum suits {
		Clubs,
		Diamonds, 
		Hearts,
		Spades;
	}
	public String img;
	
	private ranks rank;
	
	private suits suit;

	private int value; 
	
	private Card card;
	//default card constructor
	

	//official card constructor.. 
	//does this make getters/setters redundant?
	public Card(suits suit, ranks rank, int value, String imgs) { 
		
		this.suit = suit;
		this.rank = rank;
		this.value = value;
		this.img = imgs;
	} 
	
	public Card getCard() {
		return card;
	}
	
	public ranks getRank() {
		return rank;
	}
	public suits getSuit() {
		return suit;
	}
	public int getValue() {
		return value;
	}
	public String getImg() {
		return img;
	}
	public void setRank(ranks rank) {
		this.rank = rank;
	}
	public void setSuit(suits suit) {
		this.suit = suit;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public void setImg(String img) {
		this.img = img;
	}
	
	/*toString method for card test, comment out final*/
	@Override
	public String toString() {
		return " " + rank + " of " + suit ; 
	}
}
