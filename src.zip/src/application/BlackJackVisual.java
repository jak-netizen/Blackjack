package application;




import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.paint.*;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.BorderPane;

import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;



public class BlackJackVisual extends Stage{
	public static String name = "";
	
	BlackJackVisual(){
		Deck deck = new Deck();
		
		Dealer dealer = new Dealer(new Hand(), true);
		
		Player player = new Player(new Hand(), "", 50000, 0);
		
		Hand playerHand = player.getPlayerHand();
		player.setPlayerHand(playerHand);
		
		Hand dealerHand = dealer.getDealerHand();
		dealer.setDealerHand(dealerHand, true);
		
		
		Game game = new Game(deck, player, dealer);
		
		Label title = new Label("BlackJack");
		Label dealerLb = new Label("Dealer");
		dealerLb.setTextFill(Color.BLACK);
		
		Label chipsLabel = new Label("Chips:");
		
		Label nameLabel = new Label(name);
		
		Label balanceLabel = new Label("Cash: " + Double.toString(player.getBalance()));
		
		TextField input = new TextField();
		
		final Button chip1 = new Button("100");
		final Button chip2 = new Button("250");
		final Button chip3 = new Button("500");
		final Button chip4 = new Button("1K");
		final Button chip5 = new Button("2K");
		final Button chip6 = new Button("5K");
		final Button chip7 = new Button("10K");
		
		final Button submitBetBt = new Button("   BET   ");
		

		
		final Button hitBt = new Button("   HIT   ");
		final Button standBt = new Button("STAND");
		
		
		Chips chips = new Chips(chip1, chip2,chip3,chip4,chip5,chip6,chip7);
		
		NameBalance nameBalance = new NameBalance(nameLabel, balanceLabel);
		
		PlayerButtons playerButtons = new PlayerButtons(chipsLabel, hitBt, standBt, submitBetBt, chips);
		
		Label playerCards = new Label(player.getPlayerHand().toString());
		playerCards.setTextFill(Color.BLACK);
		
		PlayerPane playerPane = new PlayerPane(playerCards, nameBalance, playerButtons);
		
		
		Label dealerCards = new Label(dealer.getDealerHand().toString());
		dealerCards.setTextFill(Color.BLACK);
		
		GridPane dealerPane = new GridPane();
		dealerPane.add(dealerLb, 0, 0);
		dealerPane.add(dealerCards, 1, 1);
		
		BorderPane gameTable = new BorderPane();
		
		 
		
		
		gameTable.setRight(input);
		
		gameTable.setBottom(playerPane);
		
			
		gameTable.setTop(dealerPane);
		
		
		
		BorderPane.setAlignment(dealerLb, Pos.CENTER);
		
		
		
		game.readyDeck(deck);
		game.shuffle(deck);
			
			
		

			
			
		chip1.setOnAction(e -> player.setBet(100));
		chip2.setOnAction(e -> player.setBet(250));
		chip3.setOnAction(e -> player.setBet(500));
		chip4.setOnAction(e -> player.setBet(1000));
		chip5.setOnAction(e -> player.setBet(2000));
		chip6.setOnAction(e -> player.setBet(5000));
		chip7.setOnAction(e -> player.setBet(10000));
			
			
			
		submitBetBt.setOnAction(e -> game.bet());
			
		
		
		hitBt.setOnAction(e -> player.setHitChoice(true));
		standBt.setOnAction(e -> player.setHitChoice(false));

		
				
		gameTable.setPadding(new Insets(5,5,5,5));
		
		
		
		
		
		Image tableTop = new Image("image/blackJackTable.jpg");
		ImagePattern top = new ImagePattern(tableTop);
		
		Rectangle backGround = new Rectangle(800,400);
		backGround.setFill(top);
		Group gameGroup = new Group(gameTable, backGround);
		gameTable.toFront();
		gameTable.setMinWidth(800);
		gameTable.setMinHeight(400);
		backGround.setOpacity(.9);
		
		
		Scene scene = new Scene(gameGroup, 800, 400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		this.setScene(scene);
		this.show();
		
		
	}
	
	class GameTable extends BorderPane{
		public GameTable(PlayerPane playerPane) {
			getChildren().addAll(playerPane);
		}
	}
	
	class NameBalance extends VBox{
		
		public NameBalance(Label nameLabel, Label balanceLabel) {
			getChildren().addAll(nameLabel, balanceLabel);
			nameLabel.setTextFill(Color.BLACK);
			balanceLabel.setTextFill(Color.BLACK);
		}
	}
	
	class Chips extends HBox{
		
		public Chips(Button chip1,Button chip2,Button chip3,Button chip4,
				     Button chip5, Button chip6, Button chip7) {
			getChildren().addAll(chip1,chip2,chip3,chip4,chip5,chip6,chip7);
		}
	}
	
	class PlayerButtons extends GridPane{
		
		public PlayerButtons(Label chipsLabel,Button hitBt, Button standBt, Button submitBetBt, Chips chips) {
			getChildren().addAll(chipsLabel, hitBt, standBt, submitBetBt, chips);
			
			setColumnIndex(hitBt, 1);
			setRowIndex(hitBt, 0);
			
			setColumnIndex(standBt, 1);
			setRowIndex(standBt, 1);
			
			setColumnIndex(submitBetBt, 1);
			setRowIndex(submitBetBt, 2);
			
			setColumnIndex(chipsLabel, 0);
			setRowIndex(chipsLabel, 0);
			
			setColumnIndex(chips, 0);
			setRowIndex(chips, 1);
			
			setMargin(chips, new Insets(0,40,0,20));
			
		}
	}
	
	class PlayerPane extends GridPane {	
		public PlayerPane(Label playerCards, NameBalance nameBalance, PlayerButtons playerButtons) {
			getChildren().addAll(playerCards, nameBalance, playerButtons);
			setColumnIndex(nameBalance, 0);
			setRowIndex(nameBalance, 1);
			
			setColumnIndex(playerCards, 0);
			setRowIndex(playerCards, 2);
			
			setColumnIndex(playerButtons, 2);
			setRowIndex(playerButtons, 2);
			setHgap(100);
			
		}
	}
}













