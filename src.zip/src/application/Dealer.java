package application;

public class Dealer{
	
	private boolean hitChoice;
	
	private Hand dealerHand;

	private boolean dealerHide;
	
	
	
	public Dealer() {
		this(new Hand(), false);
	}	
	public Dealer(Hand dealerHand, boolean hitChoice) {
		this.dealerHand = dealerHand;
		this.hitChoice = hitChoice;
	}
	
	public boolean getDealerHide() {
		return dealerHide;
	}
	
	public void setDealerHide(boolean dealerHide) {
		this.dealerHide = dealerHide;
	}
	
	public Hand getDealerHand() {
		return dealerHand;
	}
	public void setDealerHand(Hand dealerHand, Boolean dealerHide) {
		
		this.dealerHand = dealerHand;
		this.dealerHide = dealerHide;
	}
	
	
	public boolean getHitChoice() {
		return hitChoice;
	}
	public void setHitChoice(boolean hitChoice) {
		this.hitChoice = hitChoice;
	}
	
	@Override
	public String toString() {
		if (!dealerHide) {
			String cardString = "";
			String valueString = "";
			for (int i = 0; i < dealerHand.getHandSize(); i++) {
				cardString += dealerHand.handCards[i].toString() + ", ";
			}
			valueString += Integer.toString(dealerHand.getHandValue());
			return "hand: " + cardString + "\nValue: " + valueString;
		}
		else {
			return dealerHand.handCards[0].toString() + ", ?";
			
		}
	}
	
}
