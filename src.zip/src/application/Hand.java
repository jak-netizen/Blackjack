package application;
  
//did I use the this keyword correctly anywhere in this game?
//who knows

public class Hand {
	
	public boolean isBlackJack;
	
	public boolean isBust;
	
	private boolean hasAce;
	
	
	
	public boolean dealerHide;
	
	private int handValue;
	
	private int handSize;
	
	Card handCards[] = new Card[11];
	
	//hand constructor empty hand
	public Hand() {
		this.handCards[0] = null;
		
		this.handCards[1] = null;		
	}
	public Card getHandCards(int i) {
		return handCards[i];
	}
	//checks hand for aces, bust, and blackjack
	public void handChecks() {
		isBust = false;
		hasAce = false;
		isBlackJack = false;
		
		for (int i = 0; i < this.handSize; i++)	
			if (handCards[i].getValue() == 11){
				this.hasAce = true;
			}
		if (this.handValue == 21) {
			this.isBlackJack = true;
		}
		if (this.handValue > 21) {
			this.isBust = true;
		}
		
	}
	
	//gets the numeric value of a hand  
	//adjusts if hand is bust but contains an ace
	public int getHandValue() {
		
		handValue = 0;
		handSize = this.getHandSize();
		for (int i = 0; i < handSize; i++) {
			handValue+= handCards[i].getValue();
		}
		this.handChecks();
		if (this.isBust) {
			if (this.hasAce) {
				handValue -=10;
				isBust = false;
			}
		}	
		return handValue;
	}
	
	/*
	 * hand is 11 cards to accommodate very rare possibility
	 *that someone makes it that far before bust
	 *since all indices are null until a card is dealt to them
	 *this method counts non null indices to get a relevant hand count
	 *
	 */  
	public int getHandSize() {
		handSize = 0;
		for (int i = 0; i < handCards.length; i++) {
			if (handCards[i] != null) {
				this.handSize = handSize + 1;
			}
		}
		return handSize;
	}
	
	
	/*
	 *  addHitCard adds cards when a player hits
	 *  nextCard determines which index to place next card in
	 *  done by setting nextCard to value of hand size
	 *  if a hand has n cards, the next open index will be n
	 *  card will then be placed in index n
	 *  
	 */
	
	public void addHitCard() {
		int nextCard = this.getHandSize();
		this.handCards[nextCard] = Deck.dealCard();
		this.getHandValue();
	}
	
	 /*
	  * clearHand clears hand by setting all its indices to null
	  * then clears all other collected hand data 
	  *  by setting them to a default state 
	  * 
	  */	
	public void clearHand() {
		for (int i = 0; i < handCards.length; i++) {
			this.handCards[i] = null;
		}

		this.handSize = 0;
		this.handValue = 0;
		this.hasAce = false;
		this.isBlackJack = false;
		this.isBust = false;
	}
	

	//to string tells us whats goin on man
	
	@Override
	public String toString() {
			String cardString = "";
			String valueString = "";
			for (int i = 0; i < getHandSize(); i++) {
				cardString += handCards[i].toString() + ", ";
			}
			valueString += Integer.toString(handValue);
			return "Hand: " + cardString + "\nValue: " + valueString;
	}
}

