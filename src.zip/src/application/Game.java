package application;



public class Game {
	//wow look at all those
	public static Deck deck;
	
	public static Player player;
	
	public static Dealer dealer;
	
	public Hand dealerHand;
	
	public Hand playerHand;
	
	public boolean hitChoice;
	
	public static boolean play;
	
	public static boolean dealerWin = false;
	
	public static boolean playerWin = false;
	
	public static boolean push = false;
	
	public static boolean gameWon = false;
	
	public static int betAmount;
	
	public Game() {
		this(new Deck(), new Player(), new Dealer());
	}
	
	public Game(Deck deck, Player player, Dealer dealer) {
		Game.deck = deck;
		Game.player = player;
		Game.dealer = dealer;		
	}
	
	public static void gameLoop() {
		
		Game game = new Game();

		Deck deck = new Deck();
		game.readyDeck(deck);
		game.shuffle(deck);
		
		Player player = new Player(new Hand(), "", 50000, 0);
		

		Dealer dealer = new Dealer(new Hand(), true);
		
		dealer.setDealerHand(new Hand(), true);
		
		
		while (player.getBalance() > 0) {	
			
			
			game.bet();
		
			if(player.getBet() != 0) {
				game.deal();
			}
	
			
			game.whoWins();
			
			game.hit();
			
			game.shuffle(deck);
				
			game.dealer();
				
			
			
			game.whoWins();
			
			game.moveMoney();	
				
			game.clearHands();
			

				
		}
		//close the scanner when the game ends
		
	}
	
	
	//ready deck acts on deck object to populate deck and perform initial shuffle
	
	public void readyDeck(Deck deck) {		
		deck.generateDeck();
		deck.shuffleDeck();
	}


	//shuffle shuffles deck, placed throughout the program
	//only takes actions if 52 cards have been dealt

	public void shuffle(Deck deck) {
			deck.shuffleDeck();
	}

	/*
	 * bet handles bet placement
	 * asks player for bet amount
	 * stores amount in a variable
	 * deducts amount from balance
	 * 
	 */


	public void bet() {
		player.setBalance(player.getBalance() - player.getBet());
	}
	 

	/*
	 * deal handles the dealing of the first 4 cards
	 * 1 to player, 1 to dealer, 1 to player, 1 to dealer
	 * also gets value of each hand for later use
	 * 
	 */


	public void deal() {
		Hand hand1 = new Hand();
		Hand hand2 = new Hand();
		
		hand1.handCards[0] = Deck.dealCard();
		
		hand2.handCards[0] = Deck.dealCard();
		
		hand1.handCards[1] = Deck.dealCard();
		
		hand2.handCards[1] = Deck.dealCard();
		
		player.setPlayerHand(hand1);
		dealer.setDealerHand(hand2, true);
				
		player.getPlayerHand().getHandValue();
		
		dealer.getDealerHand().getHandValue();
	}


	//clearHands calls clearHand from Hand, sets all cards to null
	//used at end of round to reset for next

	public void clearHands() {
		Hand hand1 = player.getPlayerHand();
		Hand hand2 = dealer.getDealerHand();
		
		hand1.clearHand();
		player.setPlayerHand(hand1);
		
		hand2.clearHand();
		dealer.setDealerHand(hand2, true);
		
	}

	/*
	 * 
	 * moveMoney handles the exchange of money placed on bets 
	 * in event of player winning, they receive twice their bet back
	 * in event of a push they receive their initial bet back
	 * in event of a loss nothing occurs because their bet is already on the table
	 * 	therefore no change to balance needed
	 * post adjustment balance is displayed at the end
	 *  
	 */


	public void moveMoney() {
		if (Game.playerWin) {
			player.setBalance(player.getBet() * 2);
		} else if (Game.push) {
			player.setBalance(player.getBalance() - player.getBet());
		} 
	}

	/*
	 * hit handles hit behavior
	 * a player may hit if:
	 *   -they have not already won
	 *   -the dealer has not already won
	 *   -they have not busted
	 * they may continue hitting until one of the above conditions is met
	 * after each hit the whoWins method is called to check for a winner
	 * 
	 */


	public void hit() {
		if (!Game.dealerWin && !Game.playerWin) {
			Hand hand1 = player.getPlayerHand();	
			hand1.addHitCard();
			
			player.getPlayerHand().handChecks();
			player.getPlayerHand().getHandValue();
			if (player.getPlayerHand().isBust || player.getPlayerHand().isBlackJack) {
				whoWins();
				player.setHitChoice(false);
			}
		}
	}

	/*
	 *  whoWins checks both hands for all possible end game conditions
	 *  finds blackJacks, busts, and value based wins/losses
	 *  flags a winner if found, push is hands equal
	 *  flags an game over boolean when a winner is found
	 *  boolean for the dealer's hidden card is used to prevent 
	 *   certain checks from being activated early
	 *  
	 */


	public void whoWins() {
		Game.playerWin = false;
		Game.dealerWin = false;
		Game.push = false;
		
		Hand hand1 = player.getPlayerHand();
		Hand hand2 = dealer.getDealerHand();
		
		hand1.handChecks();
		hand2.handChecks();

		
		if (hand2.isBlackJack && hand1.isBlackJack) {
			hand2.dealerHide = false;
			hand2.toString();
			Game.push = true;
			Game.gameWon = true;
		}
		
		else if (hand2.isBlackJack && !hand2.dealerHide) {
			hand2.dealerHide = false;
			hand2.toString();
			
			Game.dealerWin = true;
			Game.gameWon = true;
		}
		
		else if (hand1.isBlackJack) {
			
			Game.playerWin = true;
			Game.gameWon = true;
		} 
		
		else if (hand1.isBust) {
			
			Game.dealerWin = true;
			Game.gameWon = true;
		} 
		
		else if (hand2.isBust) {
			
			Game.playerWin = true;
			Game.gameWon = true;
		}

		else if (!hand2.dealerHide){

		
			if (hand1.getHandValue() > hand2.getHandValue()) {
				Game.playerWin = true;
			}
			
			 else if (hand1.getHandValue() < hand2.getHandValue()) {
				 Game.dealerWin = true;
			}
			
			 else if(hand1.getHandValue() == hand2.getHandValue()) {
				  Game.push = true;
			}
		}
	} 



	/*
	*  method that handles dealer behavior
	*  dealer hits until >16 or >player's hand, whatever comes first	
	*  reveals dealers flip card, prints hand each time card is dealt
	*  while loop will not start if a game ending condition has already been met
	*/
	public void dealer() {
		dealer.setDealerHide(false);
		Hand tempDealerHand = new Hand();
		tempDealerHand = dealer.getDealerHand();
		if (dealer.getDealerHand().getHandValue() > 16 || 
			dealer.getDealerHand().getHandValue() > player.getPlayerHand().getHandValue()) {
	  			
				dealer.setHitChoice(false);
			} else {
				dealer.setHitChoice(true);
			} 
		
		while (dealer.getHitChoice(dealer.getDealerHand(),player.getPlayerHand()) && !Game.gameWon) {
			
			tempDealerHand.addHitCard();
			
			dealer.setDealerHand(tempDealerHand, dealer.getDealerHide());
			 
			
			if (dealer.getDealerHand().getHandValue() > 16 || 
				dealer.getDealerHand().getHandValue() > player.getPlayerHand().getHandValue()) {
				
				dealer.setHitChoice(false);
			} else { 
				dealer.setHitChoice(true);
			} 
			
			whoWins();
		}
	}

}
