package application;


import application.Card.ranks;
import application.Card.suits;


public class Deck {
	

	
	public String[] imgs = new String[52];
	
	//empty 52 int array
	int[] deckTemp = new int[52];
	
	private static Card cards[];
	

	
	//fill deck array with integers 0-51
	public void generateDeck()  {
		for (int i = 0; i < deckTemp.length; i++) {
			deckTemp[i] = i;
		}
		
		for (int i = 0; i < deckTemp.length; i++) {	
			imgs[i] = "/image/" + i + ".png";	
		}
		
		//list to hold card objects
		Deck.cards = new Card[52];
		
		//creates 52 instances of card object, adds them to list
		for (int i = 0; i < deckTemp.length; i++) {
			
			//current(Suit/Rank) holds value that determines suit and rank
			int currentSuit = (deckTemp[i] / 13);
			int currentRank = (deckTemp[i] % 13);
			
			/*card objects created
			 *current(Suit/Rank) value used as index(?) of
			 *suits/values enums to determine a suit and value
			 *to use as parameters for Card constructor */ 
			int values = ranks.values()[currentRank].ordinal()+1;
			
			if (values > 9) {
				values = 10;
			}
			if (values == 1) {
				values = 11;
			}
			Card card = new Card(suits.values()[currentSuit], ranks.values()[currentRank], values, imgs[i]);
			cards[i] = card;
		}
		
	}
	
	//shuffle order of cards list
	public void shuffleDeck() {
		for (int i = 0; i < deckTemp.length; i++) {
				int index = (int)(Math.random() * deckTemp.length);
				Card temp = cards[i]; 
				cards[i] = cards[index];
				cards[index] = temp;
		}
	}
	
	
	
	public static Card dealCard() {
		Card dealtCard = cards[0];
		for(int j = 0; j < 1; j++) {
			Card top = cards[1];
			for (int i = 0; i < cards.length - 1; i++) {
				cards[i] = cards[i+1];
			}
			cards[j] = top;
		}
		return dealtCard;
	}
	

	
	/*toString method for tests, comment out on final*/
	@Override
	public String toString() {
		String cardList = " ";
		for (int i = 0; i < cards.length; i++) {
			cardList += Integer.toString(i+1) + cards[i].toString() + ", \n";
		}
		return cardList;
	}
}